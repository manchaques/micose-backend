defmodule <%= module %>View do
  use <%= base %>.Web, :view
end
